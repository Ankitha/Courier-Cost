package com.snapdeal.courier.exception;

public class WeightSlabNotFoundException extends Exception{

    private static final long serialVersionUID = -4960143127154747331L;

    public WeightSlabNotFoundException(String message) {
        super(message);
    }
}
